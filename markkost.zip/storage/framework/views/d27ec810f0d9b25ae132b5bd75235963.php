<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
    <div class="app-brand demo">
        <a href="/dashboard" class="app-brand-link">
            <span class="app-brand-logo demo">
                
                <img width="40" src="<?php echo e(asset('')); ?>logorumah.png" alt="">
            </span>
            <span class="app-brand-text demo menu-text fw-bolder ms-2">Mark Kost</span>
        </a>

        <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
            <i class="bx bx-chevron-left bx-sm align-middle"></i>
        </a>
    </div>

    <div class="menu-inner-shadow"></div>
    <?php echo $__env->make('web.template.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
</aside>
<?php /**PATH C:\laragon\www\markkost\resources\views/web/template/header.blade.php ENDPATH**/ ?>