<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Halaman /</span> Pendaftaran</h4>
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <div class="card">
            <div class="row">
                <div class="col-md-9">
                    <h5 class="card-header">Pendaftaran</h5>
                </div>
                <div class="col-md-3 mt-3">
                    <div class="mb-3">
                        <select class="form-select form-select" name="cari" id="cari">
                            <option>-- Cari Pendaftar --</option>
                            <option value="pemilik_kost" <?php echo e(Request::segment(2) == 'pemilik_kost' ? 'selected' : ''); ?>>
                                Pemilik</option>
                            <option value="penyewa" <?php echo e(Request::segment(2) == 'penyewa' ? 'selected' : ''); ?>>Pengguna
                            </option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="table-responsive text-nowrap">
                <table class="table">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>No Telp</th>
                            <th>Dokumentasi KTP</th>
                            <th>Keterangan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        <?php if(count($pendaftaran) > 0): ?>
                            <?php $__currentLoopData = $pendaftaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $pend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($index + $pendaftaran->firstItem()); ?></td>
                                    <td><?php echo e($pend->name); ?></td>
                                    <td><?php echo e($pend->no_tlp); ?></td>
                                    <td>
                                        <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal"
                                            data-bs-target="#dokktpModal<?php echo e($pend->id); ?>">
                                            Lihat KTP
                                        </button>
                                    </td>
                                    <td>
                                        <?php if($pend->level == 'pemilik_kost'): ?>
                                            <span class="badge bg-label-primary me-1">Pemilik</span>
                                        <?php else: ?>
                                            <span class="badge bg-label-info me-1">Pengguna</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><a href="/pendaftaran/<?php echo e($pend->id); ?>/edit" class="btn btn-sm btn-warning"><i
                                                class='bx bxs-edit'></i></a>

                                        <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal"
                                            data-bs-target="#deletePendaftaran<?php echo e($pend->id); ?>">
                                            <i class='bx bx-trash'></i>
                                        </button>


                                    </td>
                                </tr>
                                <div class="modal fade" id="dokktpModal<?php echo e($pend->id); ?>" tabindex="-1"
                                    aria-hidden="true">
                                    <div class="modal-dialog modal-lg" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel3">KTP <?php echo e($pend->name); ?>

                                                </h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <?php if($pend->dok_ktp): ?>
                                                    <img width="100%"
                                                        src="<?php echo e(asset('/')); ?><?php echo e(env('ASSET_UPLOAD')); ?>images/<?php echo e($pend->dok_ktp); ?>"
                                                        alt="">
                                                <?php else: ?>
                                                    <h4>KTP Belum di upload</h4>
                                                <?php endif; ?>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-outline-secondary"
                                                    data-bs-dismiss="modal">
                                                    Close
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                

                                <div class="modal fade" id="deletePendaftaran<?php echo e($pend->id); ?>" tabindex="-1"
                                    aria-hidden="true">
                                    <div class="modal-dialog modal-sm" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel3">Hapus
                                                </h5>
                                            </div>
                                            <div class="modal-body">
                                                <br>
                                                <div class="text-center">Apakah anda yakin <br> akan menghapus data <br> an.
                                                    <?php echo e($pend->name); ?> ?</div>
                                                <form action="<?php echo e(route('destroy.pendaftaran', $pend->id)); ?>" method="post"
                                                    style="display: inline-block">
                                                    <?php echo method_field('DELETE'); ?>
                                                    <?php echo csrf_field(); ?>
                                            </div>
                                            <div class="modal-footer">
                                                <button class="btn btn-danger">Hapus</button>
                                                </form>
                                                <button type="button" class="btn btn-outline-secondary"
                                                    data-bs-dismiss="modal">
                                                    Close
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr class="text-center">
                                <td colspan="6">Tidak Ditemukan</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div><br><br>
            <div class="pagination justify-content-center">
                <ul class="pagination">
                    <li class="page-item <?php echo e($pendaftaran->onFirstPage() ? 'disabled' : ''); ?>">
                        <a class="page-link" href="<?php echo e($pendaftaran->previousPageUrl()); ?>" aria-label="Previous">
                            <span aria-hidden="true">&laquo;</span>
                        </a>
                    </li>

                    <?php $__currentLoopData = $pendaftaran->getUrlRange(1, $pendaftaran->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="page-item <?php echo e($page == $pendaftaran->currentPage() ? 'active' : ''); ?>">
                            <a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <li class="page-item <?php echo e($pendaftaran->hasMorePages() ? '' : 'disabled'); ?>">
                        <a class="page-link" href="<?php echo e($pendaftaran->nextPageUrl()); ?>" aria-label="Next">
                            <span aria-hidden="true">&raquo;</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        $(document).ready(function() {
            $("#cari").change(function(e) {
                e.preventDefault();
                let cari = $("#cari").val();

                if (cari == "pemilik_kost") {
                    window.location.href = `<?php echo e(asset('/')); ?>pendaftaran/pemilik_kost`;
                } else if (cari == "penyewa") {
                    window.location.href = `<?php echo e(asset('/')); ?>pendaftaran/penyewa`;
                } else {
                    window.location.href = `<?php echo e(asset('/')); ?>pendaftaran`;
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('web.template.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\markkost\resources\views/web/pendaftaran/pendaftaran.blade.php ENDPATH**/ ?>