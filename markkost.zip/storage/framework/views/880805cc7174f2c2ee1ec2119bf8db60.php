

<?php $__env->startSection('title'); ?>
    Ubah Rekening
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Rekening /</span> Ubah</h4>
        <div class="card">
            <h5 class="card-header">Ubah Rekening</h5>
            <div class="card-body">
                <form action="<?php echo e(route('rekening.update', $rekening->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="mb-3">
                                <label for="nama_rekening" class="form-label">Nama Rekening</label>
                                <input type="text" class="form-control" id="nama_rekening" name="nama_rekening"
                                    value="<?php echo e(old('nama_rekening', $rekening->nama_rekening)); ?>" placeholder="Nama Rekening"
                                    aria-describedby="defaultFormControlHelp">
                            </div>
                            <div class="mb-3">
                                <label for="nomor_rekening" class="form-label">Nomor Rekening</label>
                                <input type="text" class="form-control" id="nomor_rekening" name="nomor_rekening"
                                    value="<?php echo e(old('nomor_rekening', $rekening->nomor_rekening)); ?>"
                                    placeholder="Nomor Rekening" aria-describedby="defaultFormControlHelp">
                            </div>
                            <div class="mb-3">
                                <label for="nama_bank" class="form-label">Nama Bank</label>
                                <input type="nama_bank" class="form-control" id="nama_bank" name="nama_bank"
                                    value="<?php echo e(old('nama_bank', $rekening->nama_bank)); ?>" placeholder="Nama Bank"
                                    aria-describedby="defaultFormControlHelp">
                            </div>
                            <div class="mb-3">
                                <label for="pengguna" class="form-label">Pemilik Kost</label>
                                <select class="form-select" id="pengguna" name="pengguna">
                                    <option>-- Pilih Keterangan --</option>
                                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($usr->id); ?>"
                                            <?php echo e(old('pengguna', $usr->id) == $rekening->user_id ? 'selected' : ''); ?>>
                                            <?php echo e($usr->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="mb-3">
                            <input type="submit" class="btn btn-primary" value="Ubah">
                        </div>
                    </div>
                </form>


            </div>
        </div>


    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        $(document).ready(function() {
            $("#cari").change(function(e) {
                e.preventDefault();
                let cari = $("#cari").val();

                if (cari == "pemilik_kost") {
                    window.location.href = `<?php echo e(asset('/')); ?>rekening/pemilik_kost`;
                } else if (cari == "penyewa") {
                    window.location.href = `<?php echo e(asset('/')); ?>rekening/penyewa`;
                } else {
                    window.location.href = `<?php echo e(asset('/')); ?>rekening`;
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('web.template.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\markkost\resources\views/web/rekening/edit.blade.php ENDPATH**/ ?>