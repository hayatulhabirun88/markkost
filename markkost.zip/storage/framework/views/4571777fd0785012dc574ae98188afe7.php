<?php $__env->startSection('title'); ?>
    Ubah Pendaftaran
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Pendaftaran /</span> Ubah</h4>
        <div class="card">
            <h5 class="card-header">Ubah Pendaftaran</h5>
            <div class="card-body">
                <form action="<?php echo e(route('update.pendaftaran', $pendaftaran->id)); ?>" method="POST"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="name" class="form-label">Nama</label>
                                <input type="text" class="form-control" id="name" name="name"
                                    value="<?php echo e(old('name', $pendaftaran->name)); ?>" placeholder="Nama"
                                    aria-describedby="defaultFormControlHelp">
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="email" name="email"
                                    value="<?php echo e(old('email', $pendaftaran->email)); ?>" placeholder="Email"
                                    aria-describedby="defaultFormControlHelp">
                            </div>
                            <div class="mb-3">
                                <label for="no_tlp" class="form-label">No Telp</label>
                                <input type="no_tlp" class="form-control" id="no_tlp" name="no_tlp"
                                    value="<?php echo e(old('no_tlp', $pendaftaran->no_tlp)); ?>" placeholder="No Telp"
                                    aria-describedby="defaultFormControlHelp">
                            </div>
                            <div class="mb-3">
                                <label for="level" class="form-label">Keterangan</label>
                                <select class="form-select" id="level" name="level">
                                    <option>-- Pilih Keterangan --</option>
                                    <option value="pemilik_kost"
                                        <?php echo e($pendaftaran->level == 'pemilik_kost' ? 'selected' : ''); ?>>
                                        Pemilik
                                    </option>
                                    <option value="penyewa" <?php echo e($pendaftaran->level == 'penyewa' ? 'selected' : ''); ?>>Penyewa
                                    </option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="">Dokumen KTP</label>
                                <div class="mb-3">
                                    <input type="file" class="form-control" name="dok_ktp" id="dok_ktp"
                                        placeholder="Dokumen KTP" aria-describedby="fileHelpId" />
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="" height="300px">
                                <div class="mb-3">
                                    <?php if($pendaftaran->dok_ktp): ?>
                                        <img class="img-fluid"
                                            src="<?php echo e(asset('/')); ?><?php echo e(env('ASSET_UPLOAD')); ?>images/<?php echo e($pendaftaran->dok_ktp); ?>"
                                            alt="">
                                    <?php else: ?>
                                        <h1>KTP tidak di upload</h1>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <input type="submit" class="btn btn-primary" value="Ubah">
                        </div>
                    </div>
                </form>


            </div>
        </div>


    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        $(document).ready(function() {
            $("#cari").change(function(e) {
                e.preventDefault();
                let cari = $("#cari").val();

                if (cari == "pemilik_kost") {
                    window.location.href = `<?php echo e(asset('/')); ?>pendaftaran/pemilik_kost`;
                } else if (cari == "penyewa") {
                    window.location.href = `<?php echo e(asset('/')); ?>pendaftaran/penyewa`;
                } else {
                    window.location.href = `<?php echo e(asset('/')); ?>pendaftaran`;
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('web.template.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\markkost\resources\views/web/pendaftaran/edit.blade.php ENDPATH**/ ?>